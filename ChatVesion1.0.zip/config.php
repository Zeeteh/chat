<?php
// Konfigurationsdaten für die Datenbank
return [
    'host' => 'localhost',       // Der Hostname des Datenbankservers
    'username' => 'sascha',     // Der Benutzername für den Datenbankzugriff
    'password' => '77?ixV72a', // Das Passwort des Datenbankbenutzers
    'database' => 'sascha',     // Der Name der zu verwendenden Datenbank
    'email_verification_enabled' => false, // false, bis SMTP funktioniert
];

?>
