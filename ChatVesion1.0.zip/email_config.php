<?php
return [
    'host' => 'smtp.gmail.com',
    'username' => 'chatmailserver00@gmail.com',
    'password' => 'ES_9cd9eff985d04f808894e2ea244fffa9', // App-spezifisches Passwort für Gmail nutzen
    'port' => 587,
    'encryption' => 'tls',
];
